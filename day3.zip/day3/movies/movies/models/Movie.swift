//
//  Movie.swift
//  movies
//
//  Created by Sarah Renshaw on 5/1/16.
//  Copyright © 2016 sartra. All rights reserved.
//

import UIKit

class Movie: NSObject {
    var title: String!
    var year: String!
    var leadActor: String!
    var image: String!
    var summary: String!
    
}
